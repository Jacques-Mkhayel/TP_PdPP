var class_socket_buffer =
[
    [ "SocketBuffer", "class_socket_buffer.html#ac5989bcaf64234947934c7106af1cf38", null ],
    [ "read", "class_socket_buffer.html#ae8a72a818dfb3a0986dc72a2e0ca5a87", null ],
    [ "readLine", "class_socket_buffer.html#afa3a2f239eb56c2e4fd4fa465f7fb54d", null ],
    [ "setReadSeparator", "class_socket_buffer.html#aca9ca0b2defa3b9e08bbbe6abafe3f16", null ],
    [ "setWriteSeparator", "class_socket_buffer.html#a165d87f2460de769fb09d84a46a793a4", null ],
    [ "socket", "class_socket_buffer.html#ace5301cb9f4b36153759d72cfc7e7969", null ],
    [ "write", "class_socket_buffer.html#ad5a49e3f1f44e735eb15d1896eebf7b3", null ],
    [ "writeLine", "class_socket_buffer.html#a96ba6ada0c8b57eacff2aa2e4e34c282", null ]
];