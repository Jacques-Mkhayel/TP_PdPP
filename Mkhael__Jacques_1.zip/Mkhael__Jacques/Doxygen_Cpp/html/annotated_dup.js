var annotated_dup =
[
    [ "Films", "class_films.html", null ],
    [ "Groupe", "class_groupe.html", null ],
    [ "Image", "class_image.html", null ],
    [ "InputBuffer", "struct_input_buffer.html", null ],
    [ "Multimedia", "class_multimedia.html", null ],
    [ "ServerSocket", "class_server_socket.html", "class_server_socket" ],
    [ "Socket", "class_socket.html", "class_socket" ],
    [ "SocketBuffer", "class_socket_buffer.html", "class_socket_buffer" ],
    [ "SocketCnx", "class_socket_cnx.html", null ],
    [ "Table", "class_table.html", null ],
    [ "TCPServer", "class_t_c_p_server.html", "class_t_c_p_server" ],
    [ "Video", "class_video.html", null ]
];