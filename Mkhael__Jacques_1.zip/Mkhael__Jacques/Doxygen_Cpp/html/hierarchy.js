var hierarchy =
[
    [ "InputBuffer", "struct_input_buffer.html", null ],
    [ "list", null, [
      [ "Groupe", "class_groupe.html", null ]
    ] ],
    [ "Multimedia", "class_multimedia.html", [
      [ "Image", "class_image.html", null ],
      [ "Video", "class_video.html", [
        [ "Films", "class_films.html", null ]
      ] ]
    ] ],
    [ "ServerSocket", "class_server_socket.html", null ],
    [ "Socket", "class_socket.html", null ],
    [ "SocketBuffer", "class_socket_buffer.html", null ],
    [ "SocketCnx", "class_socket_cnx.html", null ],
    [ "Table", "class_table.html", null ],
    [ "TCPServer", "class_t_c_p_server.html", null ]
];