var searchData=
[
  ['client_0',['Client',['../classjava_swing_1_1_client.html#a4a952cd5d14b27b28e504d034754053f',1,'javaSwing::Client']]]
];
