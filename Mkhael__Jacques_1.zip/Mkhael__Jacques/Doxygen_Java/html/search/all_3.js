var searchData=
[
  ['send_0',['send',['../classjava_swing_1_1_client.html#a0b4e7b2dd6d4197990e39144b62863b5',1,'javaSwing::Client']]]
];
