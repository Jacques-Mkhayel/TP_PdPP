var hierarchy =
[
    [ "javaSwing.Client", "classjava_swing_1_1_client.html", null ],
    [ "JFrame", null, [
      [ "javaSwing.FenetrePrincipaleActions", "classjava_swing_1_1_fenetre_principale_actions.html", null ]
    ] ]
];