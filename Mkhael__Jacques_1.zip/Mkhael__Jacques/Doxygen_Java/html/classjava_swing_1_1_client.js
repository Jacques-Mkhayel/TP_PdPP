var classjava_swing_1_1_client =
[
    [ "Client", "classjava_swing_1_1_client.html#a4a952cd5d14b27b28e504d034754053f", null ],
    [ "send", "classjava_swing_1_1_client.html#a0b4e7b2dd6d4197990e39144b62863b5", null ]
];