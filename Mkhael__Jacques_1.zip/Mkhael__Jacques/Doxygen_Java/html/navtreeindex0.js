var NAVTREEINDEX0 =
{
"annotated.html":[0,0],
"classes.html":[0,1],
"classjava_swing_1_1_client.html":[0,0,0,0],
"classjava_swing_1_1_client.html#a0b4e7b2dd6d4197990e39144b62863b5":[0,0,0,0,1],
"classjava_swing_1_1_client.html#a4a952cd5d14b27b28e504d034754053f":[0,0,0,0,0],
"classjava_swing_1_1_fenetre_principale_actions.html":[0,0,0,1],
"functions.html":[0,3,0],
"functions_func.html":[0,3,1],
"hierarchy.html":[0,2],
"index.html":[],
"pages.html":[]
};
