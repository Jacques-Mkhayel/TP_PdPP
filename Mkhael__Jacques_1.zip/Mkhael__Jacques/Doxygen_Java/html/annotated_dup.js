var annotated_dup =
[
    [ "javaSwing", null, [
      [ "Client", "classjava_swing_1_1_client.html", "classjava_swing_1_1_client" ],
      [ "FenetrePrincipaleActions", "classjava_swing_1_1_fenetre_principale_actions.html", null ]
    ] ]
];