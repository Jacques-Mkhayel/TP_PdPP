/**
 * 
 */
/**
 * 
 */
module TpJavaSwing {
	requires java.desktop;
}
