package javaSwing;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.io.IOException;
import java.awt.event.InputEvent;


public class FenetrePrincipaleActions extends JFrame {
    private static final long serialVersionUID = 1L;

    private final JTextArea textArea;

    private Client client;

    private final Action actionAjouterA;
    private final Action actionAjouterB;
    private final Action actionQuitter;

    
    public FenetrePrincipaleActions() {
        super("Multimedia ");

        //Zone de texte centrale dans JScrollPane
        textArea = new JTextArea(15, 50);


        JScrollPane scrollPane = new JScrollPane(
                textArea,
                JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
                JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED
        );

        //Création des Actions
        actionAjouterA = new AjouterAction("Ajouter A", "Ajoute une ligne via A", KeyStroke.getKeyStroke(KeyEvent.VK_1, InputEvent.CTRL_DOWN_MASK));
        actionAjouterB = new AjouterAction("Ajouter B", "Ajoute une ligne via B", KeyStroke.getKeyStroke(KeyEvent.VK_2, InputEvent.CTRL_DOWN_MASK));
        actionQuitter    = new QuitterAction("Quitter", "Quitte l'application", KeyStroke.getKeyStroke(KeyEvent.VK_Q, InputEvent.CTRL_DOWN_MASK));
        Action actionRechercher = new RechercherAction();
        Action actionLire = new LireAction();

        
        
        //Barre d'outils
        JToolBar toolBar = new JToolBar("Barre d'outils");
        toolBar.setFloatable(false); // fixe la toolbar
        // Ajouter des boutons construits à partir des Actions
        toolBar.add(actionAjouterA);
        toolBar.add(actionAjouterB);
        toolBar.addSeparator();
        toolBar.add(actionQuitter);
        toolBar.add(actionRechercher);
        toolBar.add(actionLire);

        //Barre de menus
        JMenuBar menuBar = new JMenuBar();
        JMenu menuFichier = new JMenu("Fichier");
        menuFichier.setMnemonic(KeyEvent.VK_F);
        // Créer JMenuItem à partir des mêmes Actions
        JMenuItem miA = new JMenuItem(actionAjouterA);
        JMenuItem miB = new JMenuItem(actionAjouterB);
        JMenuItem miQuit = new JMenuItem(actionQuitter);
        JMenuItem miSearch = new JMenuItem(actionRechercher);
        JMenuItem miPlay   = new JMenuItem(actionLire);
        menuFichier.add(miSearch);
        menuFichier.add(miPlay);
        
        menuFichier.add(miA);
        menuFichier.add(miB);
        menuFichier.addSeparator();
        menuFichier.add(miQuit);
        menuBar.add(menuFichier);

        //Panel sud : boutons
        JPanel southPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        southPanel.add(new JButton(actionAjouterA));
        southPanel.add(new JButton(actionAjouterB));
        southPanel.add(new JButton(actionQuitter));
        southPanel.add(new JButton(actionRechercher));
        southPanel.add(new JButton(actionLire));
        
        //Assemblage
        this.setJMenuBar(menuBar);
        this.getContentPane().add(toolBar, BorderLayout.NORTH);
        this.getContentPane().add(scrollPane, BorderLayout.CENTER);
        this.getContentPane().add(southPanel, BorderLayout.SOUTH);

        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.pack();
        this.setLocationRelativeTo(null); // centre la fenêtre
        
        try {
            client = new Client("localhost", 3331);
            textArea.append("Connecté au serveur.\n");
        } catch (IOException e) {
            textArea.append("Erreur de connexion: " + e.getMessage() + "\n");
        }

    }

    private class AjouterAction extends AbstractAction {
        private static final long serialVersionUID = 1L;
        private final String id; // "A" ou "B"
        AjouterAction(String name, String shortDesc, KeyStroke accelerator) {
            super(name);
            putValue(Action.SHORT_DESCRIPTION, shortDesc);
            // mnemonic : première lettre du nom
            if (name != null && !name.isEmpty()) {
                putValue(Action.MNEMONIC_KEY, (int) Character.toUpperCase(name.charAt(0)));
            }
            // raccourci clavier (accélérateur) stocké dans la valeur : on utilisera cette valeur pour JMenuItem
            putValue(Action.ACCELERATOR_KEY, accelerator);
            // identifiant pour savoir quelle action exacte
            this.id = name.endsWith("A") ? "A" : "B";
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            String texte = "Ligne ajoutée par le bouton " + id;
            textArea.append(texte + System.lineSeparator());
            // faire défiler vers la fin
            textArea.setCaretPosition(textArea.getDocument().getLength());
        }
    }


    private class QuitterAction extends AbstractAction {
        private static final long serialVersionUID = 1L;
        QuitterAction(String name, String shortDesc, KeyStroke accelerator) {
            super(name);
            putValue(Action.SHORT_DESCRIPTION, shortDesc);
            
            putValue(Action.MNEMONIC_KEY, KeyEvent.VK_Q);
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            System.exit(0);
        }
    }
    
    
    private class RechercherAction extends AbstractAction {
        private static final long serialVersionUID = 1L;

        RechercherAction() {
            super("Rechercher");
            putValue(Action.SHORT_DESCRIPTION, "Recherche un objet");
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            String nom = JOptionPane.showInputDialog(FenetrePrincipaleActions.this, "Nom de l’objet :");
            if (nom == null || nom.isEmpty()) return;

            try {
                String response = client.send("search " + nom);
                textArea.append(">>> Résultat de la recherche:\n" + response + "\n\n");
                textArea.setCaretPosition(textArea.getDocument().getLength());
            } catch (Exception ex) {
                textArea.append("Erreur: " + ex.getMessage() + "\n");
            }
        }
    }

    private class LireAction extends AbstractAction {
        private static final long serialVersionUID = 1L;

        LireAction() {
            super("Lire");
            putValue(Action.SHORT_DESCRIPTION, "Joue l'objet sur le serveur");
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            String nom = JOptionPane.showInputDialog(FenetrePrincipaleActions.this, "Nom de l’objet à lire :");
            if (nom == null || nom.isEmpty()) return;

            try {
                String response = client.send("play " + nom);
                textArea.append(">>> Serveur: " + response + "\n");
                textArea.setCaretPosition(textArea.getDocument().getLength());
            } catch (Exception ex) {
                textArea.append("Erreur: " + ex.getMessage() + "\n");
            }
        }
    }


    /**
     * Point d'entrée.
     */
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            FenetrePrincipaleActions fen = new FenetrePrincipaleActions();
            fen.setVisible(true);
        });
    }
}
