#ifndef IMAGE_H
#define IMAGE_H

#include <iostream>
#include "multimedia.h"
using namespace std;


class Image : public Multimedia{
private:
    float altitude = 0;
    float longitude = 0;
public:
    Image();
    Image(string nom, string fichier, float altitude, float longitude);
    ~Image();
    float getAltitude() const;
    float getLongitude() const;
    void setAltitude (float altitude);
    void setLongitude (float longitude);
    void affichage (std::ostream &) const override;
    void jouer () const override;
    string getClassName() const override;
    void write(ostream& os) const override;
    void read(istream& is) override;
};

Image::Image() : Multimedia() {}

Image::~Image(){
    cout<<"Image detruite"<<endl;
}

Image::Image(string nom, string fichier, float altitude, float longitude) : Multimedia(nom, fichier)
{
    this->altitude = altitude;
    this->longitude = longitude;
}
float Image::getAltitude() const {
    return this->altitude;
}

float Image::getLongitude() const {
    return this->longitude;
}

void Image::setAltitude(float altitude){
    this->altitude = altitude;
}

void Image::setLongitude(float longitude){
    this->longitude = longitude;
}

void Image::affichage(std::ostream &s) const {
    Multimedia::affichage(s);
    cout << Image::getAltitude() << " " << Image::getLongitude() << endl;
}

void Image::jouer() const {
    string cmd = "mpv " + getFichier() + " &";
    system(cmd.data());
}

string Image::getClassName() const{
    return "Image";
}

void Image::write(ostream& os) const{
    Multimedia::write(os);
    os<<altitude<<endl<<longitude<<endl;
}

void Image::read(istream& is){
    Multimedia::read(is);
    string lat;
    getline(is, lat);
    altitude = stod(lat);
    string longi;
    getline(is, longi);
    altitude = stod(longi);
}

#endif // IMAGE_H











