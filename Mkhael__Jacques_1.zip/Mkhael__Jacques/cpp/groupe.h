#ifndef GROUPE_H
#define GROUPE_H
#include<iostream>
using namespace std;
#include<list>
#include"multimedia.h"
#include<memory>

class Groupe : public list<shared_ptr<Multimedia>>
{
private:
    string nom{};

public:
    Groupe();

    Groupe(const string& nom){
        this->nom = nom;
    }

    string getnom() const{ return nom;}

    void affichage(ostream& s) const{
        s<<"Nom du Groupe: "<<nom;
        for(auto it = this->begin(); it != this->end(); it++){
            (*it)->affichage(s);
        }
    }

    ~Groupe(){
        cout<<"Groupe detruit!"<<endl;
    }
};

#endif // GROUPE_H
