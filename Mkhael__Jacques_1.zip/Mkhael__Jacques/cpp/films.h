#ifndef FILMS_H
#define FILMS_H


#include <iostream>
#include "video.h"
using namespace std;

class Films : public Video{
private:
    int  * tableau = nullptr;
    int taille = 0;

public:
    Films();
    Films(string nom, string fichier, int duree, int * tableau, int taille) ;
    Films (const Films& autre); // constructeur de copie
    Films& operator=(const Films& other); //operateur d'affectation
    ~Films();
    void setTableau (const int * Tableau, int taille);
    const int * getTableau () const;
    int getTaille () const;
    void affichage(ostream & s) const override;
    string getClassName() const override;
    void write(ostream& os) const override;
    void read(istream& is) override;
};

Films::Films() : Video() {}


Films::Films(string nom, string fichier, int duree,int * tableau, int taille) : Video (nom, fichier, duree) {
    if (taille > 0 && tableau != nullptr){
        this ->tableau = new int[taille];
        this ->taille = taille;
        for (int i = 0; i < taille; i++) this->tableau[i] = tableau[i];
    }
}

Films::Films(const Films& autre)
    : Video(autre), taille(autre.taille) {
    if (taille > 0 && autre.tableau != nullptr) {
        tableau = new int[taille];
        for (int i = 0; i < taille; ++i)
            tableau[i] = autre.tableau[i];
    } else {
        tableau = nullptr;
    }
}

Films& Films::operator=(const Films& other) {
    if (this != &other) {
        Video::operator=(other); // appel de l’opérateur d’affectation de la classe de base

        delete[] tableau;

        taille = other.taille;
        if (taille > 0 && other.tableau != nullptr) {
            tableau = new int[taille];
            for (int i = 0; i < taille; ++i)
                tableau[i] = other.tableau[i];
        } else {
            tableau = nullptr;
        }
    }
    return *this;
}


Films::~Films(){
    delete[] tableau;
    cout<<"Film detruit"<<endl;
}

void Films::setTableau(const int* tableau, int taille) {
    if (this->tableau != nullptr){
        delete [] this->tableau;
    }
    if (taille > 0 && tableau != nullptr){
        this ->tableau = new int[taille];
        this ->taille = taille;
        for (int i = 0; i < taille; i++) this->tableau[i] = tableau[i];
    }
    else {
        this->tableau = nullptr;
        this->taille = 0;
    }
}
const int * Films::getTableau()const {
    return this->tableau;
}

int Films::getTaille() const {
    return this->taille;
}

void Films::affichage(ostream & s)const{
    Multimedia::affichage(s);
    for (int i = 0; i < getTaille() ; i++){
        cout << "Chapitre numéro: " << i << " et de durée: " << getTableau()[i] << endl;
    }
}

string Films::getClassName() const{
    return "Film";
}

void Films::write(ostream& os) const{
    Video::write(os);
    os<<"nombre de chapitres: "<<taille;

    for(int i=0; i<taille; i++){
        os<<endl<<"chapitre numero: "<<i+1<<", duree du chapitre: "<<(getTableau())[i];
    }
}

void Films::read(istream& is){
    Video::read(is);
    string t;
    getline(is, t);
    taille = stod(t);

    delete[] tableau;
    tableau = new int[taille];
    for(int i=0; i<taille; i++){
        is>>tableau[i];
    }
}






#endif // FILMS_H
