#ifndef VIDEO_H
#define VIDEO_H

#include <iostream>
#include "multimedia.h"
using namespace std;

class Video : public Multimedia {
private:
    int duree = 0;
public:
    Video();
    Video(string nom, string fichier, int duree);
    ~Video();
    int getDuree() const;
    void setDuree(int duree);
    void affichage (std::ostream & s) const override;
    void jouer() const override;
    string getClassName() const override;
    void write(ostream& os) const override;
    void read(istream& is) override;
};

Video::Video() : Multimedia(){}

Video::~Video(){
    cout<<"Video detruite"<<endl;
}

Video::Video(string nom, string fichier, int duree) : Multimedia(nom, fichier){
    this->duree = duree;
}

int Video::getDuree()const{
    return this->duree;
}

void Video::setDuree(int duree){
    this->duree = duree;
}

void Video::affichage(ostream & s) const {
    Multimedia::affichage(s);
    cout << Video::getDuree() << endl;
}

void Video::jouer() const {
    string cmd = "mpv " + getFichier() + " &";
    system(cmd.data());
}

string Video::getClassName() const{
    return "Video";
}

void Video::write(ostream& os) const{
    Multimedia::write(os);
    os<<duree<<endl;
}

void Video::read(istream& is){
    Multimedia::read(is);
    string durr;
    getline(is, durr);
    duree = stoi(durr);
}








#endif // VIDEO_H
