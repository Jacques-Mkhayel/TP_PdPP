#include "multimedia.h"
#include <iostream>
#include <sstream>
using namespace std;

Multimedia::Multimedia(){

   this->nom = "";
   this->fichier = "";
}
Multimedia::~Multimedia(){};
Multimedia::Multimedia(string nom, string fichier){
    this->nom = nom;
    this->fichier = fichier;

}
void Multimedia::setNom(string nom){
    this->nom = nom;
}
void Multimedia::setFichier(string fichier){
    this->fichier=fichier;
}

string Multimedia::getNom () const{
    return this->nom;
}
string Multimedia::getFichier() const{
    return this->fichier;
}

void Multimedia::affichage(std::ostream & s) const{
    s << Multimedia::getNom() << " " << Multimedia::getFichier() << endl;
}
string Multimedia::getClassName() const{
    return "Multimedia";
}

void Multimedia::write(ostream& os) const{
    os<<getClassName()<<endl;
    os<<nom<<'\n'<<nom<<endl;
}

void Multimedia::read(istream& is){
    getline(is, nom);
    getline(is, fichier);
}
