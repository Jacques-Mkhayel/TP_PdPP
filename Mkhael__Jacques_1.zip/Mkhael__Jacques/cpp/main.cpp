//
// main.cpp
// Created on 21/10/2018
//
#include "multimedia.h"
#include "image.h"
#include "video.h"
#include "films.h"
#include "groupe.h"
#include "table.h"

#include "tcpserver.h"
#include "ccsocket.h"
#include <string>
#include <map>
#include <memory>
#include <iostream>



using namespace std;

//#define VERSION_OLD
#define VERSION_SERVER
//#define VERSION_SERIALISATION

#ifdef VERSION_OLD

void printJouer (Multimedia** m, int count){
    for (int i = 0; i < count; i++ ){
        m[i]->affichage(cout);
        std::cout<< endl;
    }
};
int main(int argc, const char* argv[]){
    std::cout << "Hello brave new world" << std::endl;
    //Multimedia * m = new Multimedia();
    //Multimedia * m1 = new Multimedia("videos", "test1");
    //m1->affichage(std::cout);

    //maintenant ce n'est pas possible de créer des objets de type Multimedia, car cette classe est maintenant abstraite


    Multimedia ** Jouer = new Multimedia* [10];
    int count = 0;
    Jouer[count++] = new Image("image1","fichier1",20,30);
    Jouer[count++] = new Video("video1","fichier1",200);
    printJouer (Jouer,count);

    int * chapitres1  = new  int [5]{20,40,60,80,100};
    int * chapitres2  = new int [7]{20,40,60,80,100,120,140};
    Films * f1 = new Films("Titanic", "History",120,chapitres1,5);
    Films * f2 = new Films("No Country For Old Men", "Country",150,chapitres2,7);

    cout <<"Avant la destruction du tableau du film 1 et la modification du tableau du film 2" << endl;
    f1->affichage(cout);
    f2->affichage(cout);



    delete [] chapitres1;
    cout <<"Apres la destruction du tableau du film 1"<< endl;
    f1->affichage(cout);


    int Chapitres3 [] = {10,30,50,70,90,110,130};
    cout << "Apres la modification du tableau du film 2"<<endl;
    f2->setTableau(Chapitres3, 7);
    f2->affichage(cout);
    cout << "Les Chapitres du film 2 sont: ";
    const int *  chapitre  = f2->getTableau();
    for (int i=0; i < f2->getTaille(); i++){
        cout << chapitre [i]<< ", ";
    }
    cout << endl;
    //partie 7 - copie d'un objet de type film
    Films * f3 = new Films();
    f3 = f2;
    cout << "film 3 "<< endl;
    f3->affichage(cout);



    //Partie 8 et Partie 9
    auto i1 = make_shared<Image>("MonaLisa", "Painting ", 40, 20);
    auto v1 = make_shared<Video>("Skking in Al-Arz", "my adventures", 1800);
    int duree2[] = {60, 90, 10};
    auto f4 = make_shared<Films>("Inception", "Scifi movies", 160, duree2,3);

    Groupe fichierJacques("fichierJacques");
    fichierJacques.push_back(i1);
    fichierJacques.push_back(v1);
    fichierJacques.push_back(f4);

    Groupe cinema("cinema");
    cinema.push_back(f4);

    fichierJacques.affichage(cout);
    cinema.affichage(cout);

    auto it = fichierJacques.begin();
    advance(it, 2);
    fichierJacques.erase(it);
    cout<<"\n f4 reste dans cinema mais plus dans fichierJacques !"<<endl;
    fichierJacques.affichage(cout);
    cinema.affichage(cout);

    //Partie 10
    Table t;
    int duree3[] = {20, 25, 30, 55};
    auto p2 = t.creerImage("Hilary Hann", "Musicians", 38.5, 55.5);
    auto v2 = t.creerVideo("Lebron James scoring", "Basketball", 100);
    auto f5 = t.creerFilm("12 Angry Men", "Drama", 110, duree3, 4);
    auto g2 = t.creerGroupe("Mes Fichiers");

    g2->push_back(p2);
    g2->push_back(v2);
    g2->push_back(f5);

    t.affichage(cout, "Hilary Hann");
    t.Jouer("Lebron James scoring");
    t.affichage(cout, "Mes Fichiers");
    t.affichage(cout, "12 Angry Men");
    t.affichage(cout, "Rien");
    return 0;

}
#endif

#ifdef VERSION_SERVER

int main(){
    Table t;
    auto p1 = t.creerImage("A", "Lettres", 20, 25);
    auto v1 = t.creerVideo("AVideo", "Videos", 100);
    int duree[] = {40,60,80};
    auto f1 = t.creerFilm("How to train to dragon", "HTTYD Movies", 180, duree, 3);

    auto g1 = t.creerGroupe("groupe 1");
    g1->push_back(p1);
    g1->push_back(v1);
    g1->push_back(f1);

    TCPServer server(
        [&](string const& request, string& response){
            cout<<"requete reçue: "<<request<<endl;
            stringstream ss(request);
            string commande, nom;
            ss >> commande;
            getline(ss, nom);
            nom.erase(0, nom.find_first_not_of(' ')); // remove leading spaces
            ostringstream oss;


            if(commande == "trouver"){
                auto it = t.rechercherObjet(nom);
                if(it != nullptr){
                    (*it).affichage(oss);
                } else {
                    auto it2 = t.rechercherGroupe(nom);
                    if(it2 != nullptr){
                        (*it2).affichage(oss);
                    } else oss<<"aucun objet ou groupe a le nom: "<<nom;
                }
            }

            else if(commande == "jouer"){
                auto it = t.rechercherObjet(nom);
                if(it != nullptr){
                    (*it).jouer();
                    oss<<"lecture de l'objet: "<<nom;
                } else oss<<"aucun objet a le nom: "<<nom;
            }

            else oss<<"commande inconnue: "<<commande;

            response = oss.str();
            return true;
        }
        );

    cout<<"\nserveur exécuté sur le port 3331..."<<endl;


    int status = server.run(3331);
    if(status<0){
        cerr<<"Erreur: impossible de démarrer le serveur sur le port 3331"<<endl;
        return 1;
    }
    return 0;
}

#endif


#ifdef VERSION_SERIALISATION

int main(){
    Table t;
    auto p1 = t.creerPhoto("chat", "animaux", 12.6, 28);
    auto v1 = t.creerVideo("d-day", "saving private ryan", 600);
    t.save("save.txt");

    Table t2;
    t2.load("save.txt");

    auto y = t2.findObjet("chat");
    y->affichage(cout);

    return 0;
}

#endif
















//c'est le polymorphisme qui nous permet de traiter des objets de type differents de la meme manière
