#ifndef TABLE_H
#define TABLE_H

#include <iostream>
#include <memory>
#include <map>
#include <fstream>

#include "multimedia.h"
#include "image.h"
#include "video.h"
#include "films.h"
#include "groupe.h"

using namespace std;


class Table
{

private:
    using objptr = shared_ptr<Multimedia>;
    using grpptr = shared_ptr<Groupe>;
    map <string, objptr> objets;
    map <string, grpptr> groupes;

public:
    Table(){};
    ~Table(){};

    shared_ptr<Image> creerImage(string nom, string nom_fichier, double latitude, double longitude){
        auto p = make_shared<Image>(nom, nom_fichier, latitude, longitude);
        if(objets.find(nom) != objets.end()){
            cerr<<"erreur : objet déjà créé ";
            return nullptr;
        }
        objets[nom] = p;
        return p;
    }

    shared_ptr<Video> creerVideo(string nom, string nom_fichier, int duree){
        auto v = make_shared<Video>(nom, nom_fichier, duree);
        if(objets.find(nom) != objets.end()){
            cerr<<"erreur : objet déjà créé ";
            return nullptr;
        }
        objets[nom] = v;
        return v;
    }

    shared_ptr<Films> creerFilm(string nom, string nom_fichier, int duree, int* chapitre, int nbchap){
        auto f = make_shared<Films>(nom, nom_fichier, duree, chapitre, nbchap);
        if(objets.find(nom) != objets.end()){
            cerr<<"erreur : objet déjà créé ";
            return nullptr;
        }
        objets[nom] = f;
        return f;
    }

    shared_ptr<Groupe> creerGroupe(string nom){
        auto g = make_shared<Groupe>(nom);
        if(groupes.find(nom) != groupes.end()){
            cerr<<"erreur : groupe déjà créé ";
            return nullptr;
        }
        groupes[nom] = g;
        return g;
    }

    shared_ptr<Multimedia> rechercherObjet(const string nom){
        auto it = objets.find(nom);
        if (it != objets.end()){
            return it->second;
        } else return nullptr;
    }

    shared_ptr<Groupe> rechercherGroupe(const string nom){
        auto it = groupes.find(nom);
        if (it != groupes.end()){
            return it->second;
        } else return nullptr;
    }

    void affichage(ostream& cout, const string nom){
        auto it = objets.find(nom);
        if(it != objets.end()){
            cout<<"\n proprietes de l'objet: \n";
            it->second->affichage(cout);
            return;
        } else{
            auto it2 = groupes.find(nom);
            if(it2 != groupes.end()){
                cout<<"\nproprietes du groupe: \n";
                it2->second->affichage(cout);
                return;
            }
        }
        cout<<"\naucun groupe a le nom: "<<nom<<endl;
    }

    void Jouer(const string nom){
        auto it = objets.find(nom);
        if(it != objets.end()){
            it->second->jouer();
            return;
        }
        cout << "\naucun multimedia a le nom: " << nom << endl;
    }

    void supprimerObjet(const string nom){
        auto it = objets.find(nom);
        if(it != objets.end()){
            objets.erase(it);
            cout << "\nObjet: " << nom << " à été supprimé\n";
        } else{
            cerr<<"objet n'existe pas ";
        }
    }

    void supprimerGroupe(const string nom){
        auto it = groupes.find(nom);
        if(it != groupes.end()){
            groupes.erase(it);
            cout<<"\nGroupe: "<<nom<<" à été supprimé\n";
        } else{
            cerr<<"groupe n'existe pas ";
        }
    }

    shared_ptr<Multimedia> createfromClassName(const string& classname){
        if(classname == "Photo"){
            return make_shared<Image>();
        } else if(classname == "Video"){
            return make_shared<Video>();
        } else if(classname == "Films"){
            return make_shared<Films>();
        } else return nullptr;
    }

    void save(const string& filename) const{
        ofstream file(filename);
        if(!file){
            cerr<<"fichier ne peut pas etre ouvert: "<<filename<<endl;
            return;
        }

        for(auto& it: objets){
            it.second->write(file);
        }
        file.close();
    }

    void load(const string& filename){
        ifstream file(filename);
        if(!file){
            cerr<<"fichier ne peut pas etre ouvert pour la lecture de: "<<filename<<endl;
        }

        while(true){
            string classname;
            if(!getline(file, classname)){ //getline appeler dans tous cas!!!
                break; //fin du fichier, on ne peut plus ecrire
            }
            auto obj = createfromClassName(classname);


            if(!obj){
                cerr<<"classe inconnue: "<<classname<<endl;
                break;
            }
            obj->read(file);
            objets[obj->getNom()] = obj;

        }
        file.close();
    }

};

#endif // TABLE_H
