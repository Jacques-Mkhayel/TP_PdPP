package javaSwing;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public class FenetrePrincipale extends JFrame {
    private static final long serialVersionUID = 1L;

    private final JTextArea textArea;
    private final JButton buttonAddA;
    private final JButton buttonAddB;
    private final JButton buttonQuit;


    public FenetrePrincipale() {
        super("Fenêtre principale ");


        textArea = new JTextArea(15, 50); //15 lignes et 50 colonnes
        textArea.setLineWrap(true);  // coupure de ligne automatique
        textArea.setWrapStyleWord(true);

        // Mettre le JTextArea dans un JScrollPane
        JScrollPane scrollPane = new JScrollPane(
                textArea,
                JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
                JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED
        );

        
        buttonAddA = new JButton("Ajouter A");
        buttonAddB = new JButton("Ajouter B");
        buttonQuit = new JButton("Quitter");

        //listeners
        buttonAddA.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ajouterLigne("Ligne ajoutée par le bouton A");
            }
        });

        //lambda
        buttonAddB.addActionListener((ActionEvent e) -> ajouterLigne("Ligne ajoutée par le bouton B"));

        buttonQuit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });

        //Organiser les boutons dans un JPanel
        JPanel southPanel = new JPanel();
        southPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 10));
        southPanel.add(buttonAddA);
        southPanel.add(buttonAddB);
        southPanel.add(buttonQuit);


        this.getContentPane().add(scrollPane, BorderLayout.CENTER);
        this.getContentPane().add(southPanel, BorderLayout.SOUTH);

        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.pack(); 
        this.setLocationRelativeTo(null); 
    }


    private void ajouterLigne(String ligne) {
        textArea.append(ligne + System.lineSeparator());
        textArea.setCaretPosition(textArea.getDocument().getLength());
    }


    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            FenetrePrincipale fen = new FenetrePrincipale();
            fen.setVisible(true);
        });
    }
}
