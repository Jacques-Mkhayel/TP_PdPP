#ifndef MULTIMEDIA_H
#define MULTIMEDIA_H


#include <iostream>
#include <sstream>
using namespace std;


class Multimedia{
private:
    string nom;
    string fichier;
public:
    Multimedia();
    Multimedia(string nom, string fichier);
    ~Multimedia();
    string getNom() const;
    string getFichier() const;
    void setNom (string);
    void setFichier (string);
    virtual void affichage (std::ostream & s) const;
    virtual void jouer() const =0;        //cette methode est de type virtuel et elle est declarée virtuelle
    virtual string getClassName() const;
    virtual void write(ostream& os) const;
    virtual void read(istream& is);

};






#endif // MULTIMEDIA_H
